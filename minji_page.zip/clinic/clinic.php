<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
		<title>Mingle hospital</title>
		<link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/css/common.css">
		<link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/clinic/css/clinic.css?after3">
		<script src="https://kit.fontawesome.com/e0302dc2f2.js" crossorigin="anonymous"></script>
   		<link href="https://fonts.googleapis.com/css2?family=Jua&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/clinic/js/clinic.js" defer></script>
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/js/slide.js" defer></script>
</head>
<body onload = "slide_func()">
	<!-- header -->
	<header>
		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/header.php";?>
	</header>
	<!-- nav -->
	<nav>
		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/nav.php";?>
	</nav>

	<section>
		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/main_img_slide.php"; ?>
		<div class="info">
			<div class="info_box">
				<ul class="info_hospital">
					<h1> 진료 안내 </h1>
					<li>원활한 진료를 위하여 전화예약을 먼저 하시면 편리합니다.</li>
					<li>본원은 24시간 응급진료가 가능합니다.</li>
					<li>진료기간 변경이 있을 경우에는 미리 공지사항에 공지하도록 하겠습니다.</li>
				</ul>
			</div>
			<div class="info_info">
				<article class="info_center_box">
					<ul class="info_center">
						<div class="info_flex">
							<li class="info_icon"><i class="fas fa-phone-volume"></i></li>
							<li>병원 / <h4>022.1111.2222</h4></li>
							<li>  </li>
						</div>
						<div class="info_flex">
							<li class="info_icon"><i class="far fa-clock"></i></li>
							<li>주간진료시간 / <h4>AM 9:00~ PM 10:00 </h4>
						<h6>※ 야간진료시간에는 야간 할증비가 청구되오니 일반적인 진료는 주간진료 시간을 이용해 주시길 바랍니다.</h6></li>
							<li>  </li>
						</div>
						<div class="info_flex">
							<li class="info_icon"><i class="fas fa-clock"></i></li>
							<li>야간진료시간 / <h4>AM 10:00~ PM 9:00 </h4></li>
							<li>  </li>
						</div>
						<div class="info_flex">
							<li class="info_icon"><i class="fas fa-history"></i></li>
							<li>24시간 응급진료 / <h4>365일 24시간 연중무휴</h4></li>
							<li>  </li>
						</div>
						<div class="info_flex">
							<li class="info_icon"><i class="fas fa-cut"></i></li>
							<li>미용시간안내 / <h4>AM 10:00~ PM 7:00 </h4></li>
							<li>  </li>
						</div>
						<div class="info_flex">
							<li class="info_icon"><i class="fas fa-cat"></i></li>
							<li>야옹이 운동장 & 호텔 / <h4>AM 9:00~ PM 10:00</h4> / 그외의 타임은 야간비용 별도 추가
							<br><h6>※ 면회시간 10:00~22:00 __아가들의 안정과 빠른 회복을 위해 면회시간을 30분 이내로 협조해주시면 감사드리겠습니다.</h6></li>
						</div>
					</ul>
				</article>
			</div>
		</div>
	</section>

	<!-- footer -->
	<footer>
		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/footer.php";?>
	</footer>
</body>
</html>

