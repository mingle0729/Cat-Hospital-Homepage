<div class="footer_content">

    <div class="footer_company_name">
        <ul class="footer_name">
            <li><i class="fas fa-paw"></i></li>
            <li>Mingle hospital</li>
            <li><i class="fas fa-paw"></i></li>
        </ul>
    </div>
    
    <div class="footer_company_position">
        <ul class="footer_position">
            <li>24시밍글동물병원</li>
            <li>|</li>
            <li>서울특별시 강남구 삼성동</li>
            <li>|</li>
            <li>대표전화 022.1111.2222</li>
        </ul>
    
        <ul class="footer_info">
            <li>사업자번호</li>
            <li> 1111-1111-1111</li>
            <li>대표 김민지</li>
            <li>|</li>
            <li>Copyright(C)2010~2013 CHUNGDAM ALL RIGHTS RESERVED</li>
        </ul>
    </div>

    <div class="footer_comany_icon">
        <ul class="footer_icon">
            <li><i class="fas fa-cat"></i></li>
        </ul>
    </div>

</div>




       