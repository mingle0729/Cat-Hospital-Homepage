<?php
	$name = "안지영";
	echo "$name님 반갑습니다!";
?>