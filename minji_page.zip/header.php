<?php
    session_start();
    if (isset($_SESSION["userid"])) $userid = $_SESSION["userid"];
    else $userid = "";
    if (isset($_SESSION["username"])) $username = $_SESSION["username"];
    else $username = "";
    if (isset($_SESSION["userlevel"])) $userlevel = $_SESSION["userlevel"];
    else $userlevel = "1";
    if (isset($_SESSION["userpoint"])) $userpoint = $_SESSION["userpoint"];
    else $userpoint = "";
?>

<div class= "header_service">
    <!-- top menu -->
    <div class="header_menu">
        <ul class="header_menu_content">
            <?php
            if(!$userid) {
        ?>
                <li><a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/login/login_form.php">Login</a> </li>
                <li><a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/member/member_form.php">회원가입</a></li>
                <li><a href="#">사이트맵</a></li>
        <?php
            } else {
                $logged = "{$username} . ({$userid})님 [ Point : {$userpoint} ]";
        ?>
                <li><?=$logged?> </li>
                <li><a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/login/logout.php">로그아웃</a> </li>
                <li><a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/member/member_modify_form.php">정보 수정</a></li>
	            <li><a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/member/member_delete_form.php">회원 탈퇴</a></li>
        <?php
            }
        ?>
        <?php
            if($userlevel==1) {
                ?>
                <li>|</li>
                <li><a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/admin/admin.php">관리자 모드</a></li>
                <?php
            }
        ?>
        </ul>
        <ul class="header_menu_icon">
            <li><a href="https://www.instagram.com/5417515wr/"><i class="fab fa-instagram"></i></a></li>
            <li><a href="https://www.facebook.com/cwamc"><i class="fab fa-facebook-square"></i></a></li>
            <li><a href="https://blog.naver.com/cdwoori"><i class="fab fa-blogger"></i></a></li>
        </ul>

    </div>
</div>