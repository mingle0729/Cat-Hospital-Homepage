<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://kit.fontawesome.com/e0302dc2f2.js" crossorigin="anonymous"></script>
    <link href="https://fonts.googleapis.com/css2?family=Jua&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/common.css?after">
    <script src="./js/slide.js"></script>
    
    <title>Mingle hospital</title>
</head>
<body onload = "slide_func()">

    <!-- header -->
    <header>
        <?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/header.php";?>
    </header>
    <!-- nav -->
    <nav>
        <?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/nav.php";?>
    </nav>

    <!-- main -->
    <section>
        <?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/main.php"; ?>
    </section>
    
    <!-- footer -->
    <footer>
       <?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/footer.php";?>
    </footer>
    
</body>
</html>