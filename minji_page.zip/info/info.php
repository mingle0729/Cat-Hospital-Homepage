<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
		<title>Mingle hospital</title>
		<link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/css/common.css">
		<link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/info/css/info.css?after3">
		<script src="https://kit.fontawesome.com/e0302dc2f2.js" crossorigin="anonymous"></script>
   		<link href="https://fonts.googleapis.com/css2?family=Jua&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/info/js/info.js" defer></script>
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/js/slide.js" defer></script>
</head>
<body onload = "slide_func()">
	<!-- header -->
	<header>
		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/header.php";?>
	</header>
	<!-- nav -->
	<nav>
		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/nav.php";?>
	</nav>

	<section>
		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/main_img_slide.php"; ?>

		<div class="info">
			<ul class="info_hospital">
				<h1> 병원 안내 </h1>
				<li> 항상 환자와 보호자의 만족만을 생각하며 발전해 나아가는 mingle hospitals입니다.</li>
			</ul>
			<div class="info_info">
				<ul clas="info_img">
					<img src="http://<?=$_SERVER['HTTP_HOST']?>/minji_page/img/cat.png" alt="고양이 이미지">
				</ul>
				<ul clas="info_center">
					<h1>Mingle hospital이란?</h1>
					<li>Mingle hospital은 고양이 특화 센터로 내원하여 대기하는 공간,<br> 입원하는 공간 모두 개와 분리되어 고양이가 존중받는 고양이 친화 변원입니다.</li>
					<h1>고양이 특화 센터란?</h1>
					<li>고양이가 스트레스를 덜 받고 편안함을 느낄 수 있도록, <br> 고양이 전용 페로몬 디퓨저와 따듯한 온도를 유지하여, <br> 한층 더 안정적인 환경을 제공하고 있습니다.
					<br> 또한, 입원한 고양이를 고화질의 CCTV 영상을 통해 <br> 집에서도 입원중인 아이의 모습을 만나보실 수 있습니다.
					<br> 항상 고양이의 입장에서 생각하여 병원에 내원하기 전,<br> 내원 중, 내원한 후에도 스트레스를 최소화하도록 최선을 다하겠습니다.</li>
					<h1>펠리웨이</h1>
					<li>고양이 얼굴 페로몬인 FFP(feline facial pheromone ; 상품명 feliway) <br> 디퓨저를 사용하여 고양이가 편안함을 느껴서 스트레스를 덜 받는 환경을 제공합니다.</li>
				</ul>
			</div>
		</div>
	</section>

	<!-- footer -->
	<footer>
		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/footer.php";?>
	</footer>
</body>
</html>

