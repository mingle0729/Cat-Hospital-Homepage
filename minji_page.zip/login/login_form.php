<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>mingle</title>
	    <link href="https://fonts.googleapis.com/css2?family=Jua&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
        <script src="https://kit.fontawesome.com/e0302dc2f2.js" crossorigin="anonymous"></script>
        <script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/login/js/login.js"></script>
	    <script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/js/slide.js" defer></script>
        <link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/login/css/login1.css">
        <link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/css/common.css">
    </head>
    <body>
        <header>
            <?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/header.php"; ?>
        </header>
        <!-- nav -->
        <nav>
            <?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/nav.php";?>
        </nav>

        <section>
            <div id="main_content">
                <div id="login_box">
                    <div id="login_title">
                        <span>로그인</span>
                    </div>
                    <div id="login_form">
                        <form  name="login_form" method="post" action="login.php">
                            <div id="login_input">
                                <ul>
                                    <li><input type="text" name="id" placeholder="아이디" ></li>
                                    <li><input type="password" id="pass" name="pass" placeholder="비밀번호" ></li> <!-- pass -->
                                </ul>
                            </div>
                            <div id="login_btn">
                                <input type="button" value="Login" onclick="check_input()">
                            </div>
                        </form>
                    </div> <!-- login_form -->
                </div> <!-- login_box -->
            </div> <!-- main_content -->
        </section>
        <footer>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/minji_page/footer.php"; ?>
        </footer>
    </body>
</html>

