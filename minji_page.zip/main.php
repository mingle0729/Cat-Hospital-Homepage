<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/main_img_slide.php"; ?>

<div id="main_content">

    <div class="main_left">
        <div class="main_posting_1">
            <div class="latest">
                <ul>
                    <h4 class="text">공지사항</h4>
                    <?php
                        include_once "db/db_connect.php";

                        $sql = "select * from notice order by num desc limit 5";
                        $result = mysqli_query($con, $sql);

                        if (!$result)
                            echo "<li><span>아직 게시글이 없습니다!</span></li>";
                        else {
                            while ($row = mysqli_fetch_array($result)) {
                                $regist_day = substr($row["regist_day"], 0, 10);
                                ?>
                                <li class="main_span">
                                    <span><?= $row["subject"] ?></span>
                                    <span><?= $row["name"] ?></span>
                                    <span><?= $regist_day ?></span>
                                </li>
                                <?php
                            }
                        }
                    ?>
                </ul>
            </div>
        
            <div class="latest">
                <ul>
                    <h4 class="text">최근 게시글</h4>
                    <?php
                        include_once "db/db_connect.php";

                        $sql = "select * from board order by num desc limit 5";
                        $result = mysqli_query($con, $sql);

                        if (!$result)
                            echo "<li><span>아직 게시글이 없습니다!</span></li>";
                        else {
                            while ($row = mysqli_fetch_array($result)) {
                                $regist_day = substr($row["regist_day"], 0, 10);
                                ?>
                                <li class="main_span">
                                    <span><?= $row["subject"] ?></span>
                                    <span><?= $row["name"] ?></span>
                                    <span><?= $regist_day ?></span>
                                </li>
                                <?php
                            }
                        }
                    ?>
                </ul>
            </div>
        </div>

        <div class="main_posting_2">
            <div class="latest">
                <ul>
                    <h4 class="text">인기 게시글</h4>
                    <?php
                        include_once "db/db_connect.php";

                        $sql = "select * from board order by hit desc limit 5";
                        $result = mysqli_query($con, $sql);

                        if (!$result)
                            echo "<li><span>아직 게시글이 없습니다!</span></li>";
                        else {
                            while ($row = mysqli_fetch_array($result)) {
                                $regist_day = substr($row["regist_day"], 0, 10);
                                ?>
                                <li class="main_span">
                                    <span><?= $row["subject"] ?></span>
                                    <span><?= $row["name"] ?></span>
                                    <span><?= $regist_day ?></span>
                                </li>
                                <?php
                            }
                        }
                    ?>
                </ul>
            </div>
            <div class="latest">
                <ul>
                    <h4 class="text">포인트 랭킹</h4>
                    <?php
                        $rank = 1;
                        $sql = "select * from members order by point desc limit 5";
                        $result = mysqli_query($con, $sql);

                        if (!$result)
                            echo "<li>아직 가입된 회원이 없습니다!</li>";
                        else {
                            while ($row = mysqli_fetch_array($result)) {
                                $name = $row["name"];
                                $id = $row["id"];
                                $point = $row["point"];
                                $name = mb_substr($name, 0, 1) . " * " . mb_substr($name, 2, 1);
                                ?>
                                <li class="main_span">
                                    <span><?= $rank ?></span>
                                    <span><?= $name ?></span>
                                    <span><?= $id ?></span>
                                    <span><?= $point ?></span>
                                </li>
                                <?php
                                $rank++;
                            }
                        }
                        mysqli_close($con);
                    ?>
                </ul>
            </div>
        </div>
    </div>

        
    <div class="main_right">
        <ul>
            <h4 class="text">동물들을 도와줘요!</h4>
            <li>
                <img src="http://<?=$_SERVER['HTTP_HOST']?>/minji_page/img/helpCat.png" alt="고양이 이미지">
                <span><br>아픈 유기묘들을 데려와주세요</span>
            </li>     
        </ul>
    </div>

</div>
