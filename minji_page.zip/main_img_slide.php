
    <div class="slide_box">
        <div class="slide_img_box">
            <a href="#"><img src="http://<?=$_SERVER['HTTP_HOST']?>/minji_page/img/hospital1.png" alt="첫번째 병원이미지"></a>
            <a href="#"><img src="http://<?=$_SERVER['HTTP_HOST']?>/minji_page/img/hospital2.png" alt="두번째 병원이미지"></a>
            <a href="#"><img src="http://<?=$_SERVER['HTTP_HOST']?>/minji_page/img/hospital3.png" alt="세번째 병원이미지"></a>
        </div>
        <div class="slide_nav">
            <a href="#" class="prev">prev</a>
            <a href="#" class="next">next</a>
        </div>
    </div>
