<?php
    include_once $_SERVER["DOCUMENT_ROOT"]."/minji_page/db/db_connect.php";
    $id = $_POST["id"];

    $sql = "delete from members where id='$id'";
    $value = mysqli_query($con, $sql) or die('error : ' . mysqli_error($con));

    if ($value) {
        echo "<script>
                    alert('그동안 감사했습니다.');
              </script>";
    } else {
        echo "<script>
                    alert('회원 탈퇴 실패');
                    history.go(-1);
              </script>";
    }

    include_once $_SERVER['DOCUMENT_ROOT'] . "/minji_page/login/logout.php";
?>






