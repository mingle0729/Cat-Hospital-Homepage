<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Mingle hospital</title>
		<link rel="stylesheet" type="text/css" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/css/common.css">
		<link rel="stylesheet" type="text/css" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/member/css/member.css?after3">
		<script src="https://kit.fontawesome.com/e0302dc2f2.js" crossorigin="anonymous"></script>
   		<link href="https://fonts.googleapis.com/css2?family=Jua&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
    	<link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
		<script src="js/member_modify.js"></script>
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/js/slide.js" defer></script>
	</head>
	<body>
		<header>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/minji_page/header.php"; ?>
		</header>
		<!-- nav -->
		<nav>
			<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/nav.php";?>
		</nav>
		<section>
			<div id="main_content">
				<div id="withdrawal_box">
					<h2>정말로 회원탈퇴를 진행하시겠습니까?</h2>
					<form name="member_form" method="post" action="member_delete.php">
						<input type="hidden" name="id" value="<?=$userid?>">
						<br><br>
						<div class="delete_button">
							<input type="submit" value="확인">
						</div>
					</form>
				</div> 
			</div>
		</section>
		<footer>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/minji_page/footer.php"; ?>
		</footer>
	</body>
</html>

