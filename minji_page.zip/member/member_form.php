<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Mingle hospital</title>
		<link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/css/common.css">
		<link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/member/css/member.css?after3">
		<script src="https://kit.fontawesome.com/e0302dc2f2.js" crossorigin="anonymous"></script>
   		<link href="https://fonts.googleapis.com/css2?family=Jua&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
		<script src="./js/member.js" defer></script>
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/js/slide.js" defer></script>
	</head>
	<body>
		 <!-- header -->
		<header>
        	<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/header.php";?>
   		</header>
		<!-- nav -->
		<nav>
			<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/nav.php";?>
		</nav>

		<section>
			<div id="main_content">
				<div id="join_box">
					<h2>회원 기본 정보 입력</h2>
					<form name="member_form" method="post" action="member_insert.php">
						<table>
							<tr>
								<th>이름</th>
								<td><input type="text" name="name">
								</td>
							</tr>
							<tr>
								<th>아이디</th>
								<td><input type="text" name="id">
									<input type="button" value="중복 확인" onclick="check_id()"></td>
							</tr>
							<tr>
								<th>비밀번호</th>
								<td><input type="password" name="pass" placeholder="비밀번호 확인">
								</td>
							</tr>
							<tr>
								<th>비밀번호 확인</th>
								<td colspan="2"><input type="password" name="pass_confirm" placeholder="비밀번호 확인"></td>
							</tr>
							<tr>
								<th>E-mail</th>
								<td><input type="text" name="email1">@<input type="text" name="email2">
								</td>
							</tr>
						</table>
						<br>
						<div id="check">
							<input type="button" value="회원가입" onclick="check_input()">
							
						</div>
					</form>
				</div> <!-- join_box -->
			</div> <!-- main_content -->
		</section>

		<!-- footer -->
		<footer>
      		<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/footer.php";?>
		</footer>
	</body>
</html>

