<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/minji_page/db/db_connect.php';

$id = $_POST['id'];
$pass = $_POST['pass'];
$name = $_POST['name'];
$email1 = $_POST['email1'];
$email2 = $_POST['email2'];

$email = $email1 . '@' . $email2;

$sql = "update members set pass='$pass', name='$name' , email='$email'";
$sql .= " where id='$id'";
//select => record set, update, insert, delete => true, false
$value = mysqli_query( $con, $sql ) or die( 'error : ' . mysqli_error( $con ) ); 
//위에 적힌 쿼리문실행 or 에러가 나면 에러 메세지를 주고 죽어라! 라는 의미
//벨류값은 true , 에러가 나면 false or null

if ( $value ) {
    session_start();
    $_SESSION['username'] = $name;
} else {
    echo "<script>
        alert('정보 수정 실패');
        history.go(-1);
    </script>";
}

mysqli_close( $con );

echo "
         <script>
             alert('수정 완료');
             location.href = 'http://{$_SERVER['HTTP_HOST']}/minji_page/index.php';
         </script>
     ";
?> 