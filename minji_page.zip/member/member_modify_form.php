<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>mingle</title>
		<link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/css/common.css">
		<link rel="stylesheet" href="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/member/css/member_modify.css?after3">
		<script src="https://kit.fontawesome.com/e0302dc2f2.js" crossorigin="anonymous"></script>
    	<link href="https://fonts.googleapis.com/css2?family=Jua&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
    	<link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/js/slide.js" defer></script>
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/member/js/member_modify.js" defer></script>
	</head>
	<body>
		<header>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/minji_page/header.php"; ?>
		</header>
        <?php
            include_once $_SERVER['DOCUMENT_ROOT']."/minji_page/db/db_connect.php";
            $sql = "select * from members where id='$userid'";
            $result = mysqli_query($con, $sql);
            $row = mysqli_fetch_array($result); 

            $pass = $row["pass"];
            $name = $row["name"];

            $email = explode("@", $row["email"]);
            $email1 = $email[0];
            $email2 = $email[1];

            mysqli_close($con);
        ?>
		<nav>
			<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/nav.php";?>
		</nav>
		<section>
			<div id="main_content">
				<div id="modify_box">

					<h2>회원 정보 수정</h2>
					<form name="member_form" method="post" action="member_modify.php">
						<table>
							<tr>
								<th>이름</th>
								<td><input type="text" name="name" value="<?= $name ?>">
								</td>
							</tr>
							<tr>
								<th>아이디</th>
								<td><?= $userid ?>	<input type="hidden" name="id" value="<?=$userid?>"> <!-- id를 감추고 보여줌 -->
							</tr>
							<tr>
								<th>비밀번호</th>
								<td><input type="password" name="pass" value="<?= $pass ?>">
									
								</td>
							</tr>
							<tr>
								<th>비밀번호 확인</th>
								<td colspan="2"><input type="password" name="pass_confirm" value="<?= $pass ?>"></td>
							</tr>
							<tr>
								<th>E-mail</th>
								<td><input type="text" name="email1" value="<?= $email1 ?>">@<input type="text" name="email2" value="<?= $email2 ?>">

								</td>
							</tr>
						</table>
						<br>
						<div class="modify_btn">
							<input type="button" value="수정" onclick="check_input()"> 
							<input type="button" value="취소" onclick="location.href='http://<?=$_SERVER['HTTP_HOST']?>/minji_page/index.php'">
						</div>
					</form>
				</div>
			</div>
		</section>
		<footer>
            <?php include $_SERVER['DOCUMENT_ROOT'] . "/minji_page/footer.php"; ?>
		</footer>
	</body>
</html>

