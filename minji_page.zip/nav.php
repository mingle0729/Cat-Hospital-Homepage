<div class= "nav_menu">
    <!-- homepage theme name -->
    <div class="nav_company_name">
        <a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/index.php"><i class="fas fa-paw"></i></a>
        <a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/index.php">Mingle hospital</a>
        <a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/index.php"><i class="fas fa-paw"></i></a>
    </div>
    
    <!-- bottom menu bar -->
    <div class="nav_menubar">
        <ul>
            <li><a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/info/info.php">병원소개</a></li>
            <li><a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/clinic/clinic.php">진료안내</a></li>
            <li><div class="dropdown">
                <button class="dropdown-button">고객지원</button>
                <div class="dropdown-content">
                    <a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/notice/notice_list.php">공지사항</a>
                    <a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/free/list.php">문의하기</a>
                </div>
	        </div>
            <li><div class="dropdown">
                <button class="dropdown-button">커뮤니티</button>
                <div class="dropdown-content">
                    <a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/image_board/board_list.php">냥냥's Picture</a>
                    <a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/board/board_list.php">냥냥 진료 후기</a>
                    <a href="http://<?=$_SERVER['HTTP_HOST'];?>/minji_page/memo/message_box.php?mode=rv">쪽지보내기</a>
                </div>
	        </div></li>
            
        </ul>
    </div >

</div>
