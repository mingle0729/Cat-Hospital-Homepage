<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Mingle Hospital</title>
		<link rel="stylesheet" type="text/css" href="http://<?= $_SERVER['HTTP_HOST'] ?>/minji_page/css/common.css">
		<link rel="stylesheet" type="text/css" href="http://<?= $_SERVER['HTTP_HOST'] ?>/minji_page/notice/css/notice.css">
		<script src="http://<?=$_SERVER['HTTP_HOST'] ?>/minji_page/notice/js/notice.js"></script>
		<script src="http://<?=$_SERVER["HTTP_HOST"]?>/minji_page/js/slide.js" defer></script>
		<script src="https://kit.fontawesome.com/e0302dc2f2.js" crossorigin="anonymous"></script>
		<link href="https://fonts.googleapis.com/css2?family=Jua&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
		<link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic&display=swap" rel="stylesheet">
	</head>
	<body>
		<header>
            <?php include  $_SERVER['DOCUMENT_ROOT'] . "/minji_page/header.php"; ?>
		</header>
		<?php
            if (!$userid) {
                echo("<script>
				alert('로그인 후 이용해주세요!');
				history.go(-1);
				</script>
			");
                exit;
            }
        ?>

		<nav>
			<?php include $_SERVER['DOCUMENT_ROOT']."/minji_page/nav.php";?>
		</nav>
		<section>
            
			<div id="notice_box">
				<h3 class="title">
					공지사항 > 내용보기
				</h3>
                <?php
                    include_once $_SERVER['DOCUMENT_ROOT'] . "/minji_page/db/db_connect.php";
                    $num = $_GET["num"];
                    $page = $_GET["page"];

                    $sql = "select * from notice where num=$num";
                    $result = mysqli_query($con, $sql);

                    $row = mysqli_fetch_array($result);
                    $id = $row["id"];
                    $name = $row["name"];
                    $regist_day = $row["regist_day"];
                    $subject = $row["subject"];
                    $content = $row["content"];
                    $hit = $row["hit"];

                    $content = str_replace(" ", "&nbsp;", $content);
                    $content = str_replace("\n", "<br>", $content);
                    if ($userid !== $id) {
                        $new_hit = $hit + 1;
                        $sql = "update notice set hit=$new_hit where num=$num";
                        mysqli_query($con, $sql);
                    }


                ?>
				<ul id="view_content">
					<li>
						<span class="col1"><b>제목 :</b> <?= $subject ?></span>
						<span class="col2"><?= $name ?> | <?= $regist_day ?></span>
					</li>
					<li>
                        <?= $content ?>
					</li>
				</ul>
				<ul class="buttons">

					<?php
					 	$writer = $row["id"];
                        if( $userlevel == 1 || $userid == $writer) {
                    ?>
						<li><button onclick="location.href='notice_list.php'">목록</button></li>
						<li>
							<button onclick="location.href='notice_modify_form.php?num=<?= $num ?>&page=<?= $page ?>'">수정</button>
						</li>
						<li>
							<button onclick="location.href='notice_delete.php?num=<?= $num ?>&page=<?= $page ?>'">삭제</button>
						</li>
						<li>
								<button onclick="location.href='notice_form.php'">글쓰기</button>
							</li>
                    <?php
                        } else {
                    ?>
						<li>
							<button onclick="location.href='notice_list.php?page=<?= $page ?>'">목록</button>
						</li>
                    <?php
                        } 
                    ?>

				</ul>
			</div> <!-- notice_box -->
		</section>
		<footer>
            <?php include  $_SERVER['DOCUMENT_ROOT'] . "/minji_page/footer.php"; ?>
		</footer>
	</body>
</html>
